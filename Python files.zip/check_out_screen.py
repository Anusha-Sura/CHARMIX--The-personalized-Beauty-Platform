import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

import customtkinter as ctk
from PIL import Image, ImageTk
from tkinter import messagebox
import subprocess
import mysql.connector

from cart_system import (
    get_cart_db,
    update_qty_db,
    remove_cart_item_db,
    clear_cart_db,
)

from db_config import get_connection

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

root = ctk.CTk()
root.title("Charmix - Cart Checkout")
root.geometry("1100x750")
root.configure(fg_color="#D6A7F5")

WHITE = "#FFFFFF"
TEXT = "#222222"


# ---------------- IMAGE LOADER ----------------
def load_img(path):
    try:
        img = Image.open(path).resize((80, 80))
        return ImageTk.PhotoImage(img)
    except:
        return None


# ---------------- FETCH CART FROM DB ----------------
USER_ID = 1
cart_items = get_cart_db(USER_ID)


# ---------------- UPDATE SUMMARY ----------------
def update_summary():
    total_items = sum(item["qty"] for item in cart_items)
    subtotal = sum(item["qty"] * float(item["price"]) for item in cart_items)
    tax = 2
    final = subtotal + tax

    total_items_label.configure(text=f"Total items :      {total_items}")
    subtotal_label.configure(text=f"Sub total :       ${subtotal}")
    total_label.configure(text=f"Order Total :  ${final}")


# ---------------- REMOVE ITEM ----------------
def remove_item(index):
    remove_cart_item_db(cart_items[index]["id"])
    refresh_cart()


# ---------------- CART ITEM CARD ----------------
def make_cart_item(parent, item, index):

    frame = ctk.CTkFrame(
        parent, fg_color=WHITE,
        width=720, height=120, corner_radius=25
    )
    frame.pack(pady=10, padx=5)

    img = load_img(item["product_img"])
    if img:
        label = ctk.CTkLabel(frame, image=img, text="")
        label.image = img
        label.place(x=10, y=18)

    ctk.CTkLabel(frame, text=item["product_title"],
        font=("Arial", 14, "bold"), text_color=TEXT,
        wraplength=300, justify="left"
    ).place(x=120, y=30)

    ctk.CTkLabel(frame, text=f"${item['price']}",
        font=("Arial", 15, "bold"), text_color=TEXT
    ).place(x=600, y=10)

    def decrease_qty():
        if item["qty"] > 1:
            item["qty"] -= 1
            update_qty_db(item["id"], item["qty"])
        else:
            remove_item(index)
            return
        refresh_cart()

    def increase_qty():
        item["qty"] += 1
        update_qty_db(item["id"], item["qty"])
        refresh_cart()

    ctk.CTkButton(frame, text="-", width=30, fg_color="#4A90E2",
                  command=decrease_qty).place(x=430, y=45)

    qty_label = ctk.CTkLabel(frame, text=str(item["qty"]), font=("Arial", 14))
    qty_label.place(x=475, y=45)

    ctk.CTkButton(frame, text="+", width=30, fg_color="#4A90E2",
                  command=increase_qty).place(x=505, y=45)

    ctk.CTkButton(frame, text="Remove", fg_color="transparent",
                  text_color="black", command=lambda: remove_item(index)).place(x=550, y=55)


# ---------------- REFRESH CART DISPLAY ----------------
def refresh_cart():
    global cart_items
    cart_items = get_cart_db(USER_ID)

    for widget in cart_scroll_frame.winfo_children():
        widget.destroy()

    for i, item in enumerate(cart_items):
        make_cart_item(cart_scroll_frame, item, i)

    update_summary()


# ---------------- HEADER ----------------
search_frame = ctk.CTkFrame(root, width=650, height=45,
                            border_color="#D9D9D9", border_width=3,
                            fg_color=WHITE, corner_radius=40)
search_frame.place(x=220, y=30)

ctk.CTkEntry(search_frame, placeholder_text="Search", width=580,
             height=40, border_width=0, fg_color=WHITE).place(x=50, y=8)


def go_back():
    root.destroy()
    subprocess.Popen(["python", "homescreen_2.py"])

back_btn = ctk.CTkButton(
    root, text="⟵ Back",
    width=80, height=35,
    fg_color="#CFA0E9",
    hover_color="#B07AD9",
    text_color="black",
    font=("Arial", 14, "bold"),
    corner_radius=15,
    command=go_back
)
back_btn.place(x=40, y=30)

# ---------------- TITLE ----------------
ctk.CTkLabel(root, text="Your Cart", font=("Arial", 28, "bold"),
             text_color=TEXT).place(x=40, y=95)


# ---------------- CART SCROLL FRAME ----------------
cart_scroll = ctk.CTkScrollableFrame(
    root, width=780, height=580, fg_color="#D6A7F5"
)
cart_scroll.place(x=0, y=140)

cart_scroll_frame = cart_scroll


# ---------------- ORDER SUMMARY BOX ----------------
summary_box = ctk.CTkFrame(root, width=250, height=160,
                           fg_color=WHITE, corner_radius=25)
summary_box.place(x=820, y=100)

ctk.CTkLabel(summary_box, text="Order Summary", font=("Arial", 18, "bold")).place(x=50, y=10)

total_items_label = ctk.CTkLabel(summary_box, text="", font=("Arial", 14))
total_items_label.place(x=30, y=50)

subtotal_label = ctk.CTkLabel(summary_box, text="", font=("Arial", 14))
subtotal_label.place(x=30, y=75)

ctk.CTkLabel(summary_box, text="Tax :                $2", font=("Arial", 14)).place(x=30, y=100)

total_label = ctk.CTkLabel(summary_box, text="", font=("Arial", 14, "bold"))
total_label.place(x=30, y=125)


# ---------------- PAYMENT BOX ----------------
pay_box = ctk.CTkFrame(root, width=250, height=430,
                       fg_color=WHITE, corner_radius=25)
pay_box.place(x=820, y=290)

ctk.CTkLabel(pay_box, text="Payment method", font=("Arial", 16, "bold")).place(x=50, y=10)

card_entry = ctk.CTkEntry(pay_box, placeholder_text="Card number", width=200)
card_entry.place(x=25, y=50)

month_entry = ctk.CTkEntry(pay_box, placeholder_text="MM/YY", width=90)
month_entry.place(x=25, y=90)

cvv_entry = ctk.CTkEntry(pay_box, placeholder_text="CVV", width=90)
cvv_entry.place(x=135, y=90)

name_entry = ctk.CTkEntry(pay_box, placeholder_text="Name on the card", width=200)
name_entry.place(x=25, y=140)

contact_entry = ctk.CTkEntry(pay_box, placeholder_text="Contact Number", width=200)
contact_entry.place(x=25, y=180)

address_entry = ctk.CTkEntry(pay_box, placeholder_text="Street address", width=200)
address_entry.place(x=25, y=220)

city_entry = ctk.CTkEntry(pay_box, placeholder_text="City", width=200)
city_entry.place(x=25, y=260)

state_entry = ctk.CTkEntry(pay_box, placeholder_text="State", width=90)
state_entry.place(x=25, y=305)

zip_entry = ctk.CTkEntry(pay_box, placeholder_text="Postal code", width=90)
zip_entry.place(x=135, y=305)



# ---------------- PLACE ORDER ----------------
def place_order():

    if len(cart_items) == 0:
        messagebox.showerror("Error", "Your cart is empty!")
        return

    fields = [
        card_entry.get(),
        month_entry.get(),
        cvv_entry.get(),
        name_entry.get(),
        contact_entry.get(),
        address_entry.get(),
        city_entry.get(),
        state_entry.get(),
        zip_entry.get()
    ]

    if any(f.strip() == "" for f in fields):
        messagebox.showerror("Missing Info", "Please fill all payment details.")
        return

    try:
        conn = get_connection()
        cursor = conn.cursor()

        # Insert order
        cursor.execute("""
            INSERT INTO orders (user_id, total_items, subtotal, tax, order_total, status, order_date)
            VALUES (%s, %s, %s, %s, %s, 'placed', NOW())
        """, (
            USER_ID,
            sum(item["qty"] for item in cart_items),
            sum(item["qty"] * float(item["price"]) for item in cart_items),
            2,
            sum(item["qty"] * float(item["price"]) for item in cart_items) + 2
        ))

        order_id = cursor.lastrowid

        # Insert each item
        for item in cart_items:
            item_total = float(item["price"]) * item["qty"]

            cursor.execute("""
                INSERT INTO order_items (order_id, title, price, qty, item_total)
                VALUES (%s, %s, %s, %s, %s)
            """, (
                order_id,
                item["product_title"],
                float(item["price"]),
                item["qty"],
                item_total
            ))

        conn.commit()

    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", f"Could not place order:\n{err}")
        return

    finally:
        cursor.close()
        conn.close()

    # Clear cart
    clear_cart_db(USER_ID)

    # SUCCESS POPUP
    popup = ctk.CTkToplevel(root)
    popup.geometry("420x240+500+300")
    popup.title("Order Placed")
    popup.grab_set()

    box = ctk.CTkFrame(
        popup, width=420, height=240,
        fg_color="#E8C2FF", corner_radius=20
    )
    box.pack(fill="both", expand=True)

    ctk.CTkLabel(
        box,
        text="💜 Thank You for Choosing CHARMIX 💜",
        font=("Arial", 18, "bold"),
        text_color="#7A1CAC"
    ).pack(pady=20)

    ctk.CTkLabel(
        box,
        text="Your order has been placed successfully! ✨",
        font=("Arial", 14),
        text_color="black"
    ).pack(pady=5)

    def go_home():
        popup.destroy()
        root.destroy()
        subprocess.Popen(["python", "homescreen_1.py"])

    ctk.CTkButton(
        box,
        text="OK 💖",
        width=150, height=40,
        corner_radius=20,
        fg_color="#C273FF",
        hover_color="#A347FF",
        text_color="white",
        font=("Arial", 15, "bold"),
        command=go_home
    ).pack(pady=25)


# BUTTON
ctk.CTkButton(pay_box, text="Place order", width=180,
              text_color="black", fg_color="#CFA0E9",
              border_color="black", border_width=2,
              command=place_order).place(x=34, y=350)


refresh_cart()
root.mainloop()
