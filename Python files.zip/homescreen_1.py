import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
import customtkinter as ctk 
from PIL import Image, ImageTk

# ---------- APP CONFIG ----------
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

root = ctk.CTk()
root.title("Charmix - homescreen_1")
root.geometry("900x700")
root.configure(fg_color="#D6A7F5")   # lavender
root.resizable(False, False)

# ---------- COLORS ----------
BANNER_BG = "#FDC7D9"
PINK_BTN = "#e0568f"
WHITE = "#ffffff"
DARK_TEXT = "#2b2b2b"
LIGHT_CARD = "#ffeef7"

# ---------- NAVIGATION FUNCTIONS ----------
def open_home2():
    os.system('python "homescreen_2.py"')

def open_home3():
    os.system('python "homescreen_3.py"')

def open_home4():
    os.system('python "homescreen_4.py"')

def open_home5():
    os.system('python "homescreen_5.py"')

# ------------ SEARCH LOGIC ------------
def search_action():
    query = search_entry.get().strip().lower()

    if "oil" in query or "oily" in query:
        open_home2()
    elif "dry" in query:
        open_home3()
    elif "hair" in query or "haircare" in query:
        open_home4()
    elif "makeup" in query:
        open_home5()

# ---------- HEADER ----------
try:
    logo_img = Image.open("images/1.jpg").resize((45, 45))
    logo_photo = ImageTk.PhotoImage(logo_img)
    ctk.CTkLabel(root, image=logo_photo, text="").place(x=40, y=15)
except:
    ctk.CTkLabel(root, text="C", font=("Arial", 30)).place(x=25, y=15)

ctk.CTkLabel(root, text="harmix",
             font=("Poppins", 26, "bold"), text_color=DARK_TEXT).place(x=80, y=20)

menu_btn = ctk.CTkButton(root, text="☰", width=38, height=38,
                         fg_color="#6c4ba5", corner_radius=50)
menu_btn.place(x=825, y=15)

# ---------- SEARCH ----------
search_frame = ctk.CTkFrame(root, width=700, height=40,
                             fg_color=WHITE, corner_radius=25,
                             border_color="black", border_width=2)
search_frame.place(x=70, y=70)

try:
    search_icon = Image.open("images/2.jpg").resize((20, 20))
    search_icon_photo = ImageTk.PhotoImage(search_icon)
    ctk.CTkLabel(search_frame, image=search_icon_photo, text="").place(x=13, y=9)
except:
    ctk.CTkLabel(search_frame, text="1", font=("Arial", 16)).place(x=10, y=7)

search_entry = ctk.CTkEntry(
    search_frame, width=650, height=30,
    placeholder_text="Search for beauty products",
    fg_color=WHITE, border_width=0
)
search_entry.place(x=45, y=5)

search_entry.bind("<Return>", lambda e: search_action())

# ---------- BANNER ----------
banner = ctk.CTkFrame(root, width=795, height=165,
                      corner_radius=25, fg_color=BANNER_BG)
banner.place(x=30, y=130)

ctk.CTkLabel(banner, text="Glow everyday",
             font=("Poppins", 28, "bold"), text_color=DARK_TEXT).place(x=165, y=20)

ctk.CTkLabel(banner, text="Discover the best beauty products for you",
             font=("Poppins", 18), text_color=DARK_TEXT).place(x=135, y=70)

ctk.CTkButton(banner, text="Shop Now", width=125, height=40,
              fg_color=PINK_BTN, corner_radius=18,
              border_color="black", border_width=2,
              font=("Poppins", 18, "bold"),
              command=open_home2).place(x=225, y=110)

try:
    banner_img = Image.open("images/3.jpg").resize((200, 200))
    banner_photo = ImageTk.PhotoImage(banner_img)
    ctk.CTkLabel(banner, image=banner_photo, text="").place(x=600, y=5)
except:
    pass

# ---------- CATEGORY ----------
ctk.CTkLabel(root, text="Shop by Category",
             font=("Poppins", 20, "bold"), text_color=DARK_TEXT).place(x=30, y=330)

categories = [
    ("images/M.jpg", "Makeup"),
    ("images/H.jpg", "Haircare"),
    ("images/N.jpg", "Skincare"),
]

xpos = 50
for icon_file, label in categories:
    try:
        icon = Image.open(icon_file).resize((70, 70))
        icon_photo = ImageTk.PhotoImage(icon)

        box = ctk.CTkFrame(root, width=90, height=90,
                           fg_color=LIGHT_CARD, corner_radius=20)
        box.place(x=xpos, y=370)

        ctk.CTkLabel(box, image=icon_photo, text="").place(relx=0.5, rely=0.5, anchor="center")
    except:
        ctk.CTkLabel(root, text="2", font=("Arial", 30)).place(x=xpos+30, y=395)

    ctk.CTkLabel(root, text=label,
                 font=("Poppins", 14)).place(x=xpos+10, y=465)

    xpos += 300

# ---------- TOP PICKS ----------
ctk.CTkLabel(root, text="Top pick for you",
             font=("Poppins", 20, "bold"), text_color=DARK_TEXT).place(x=30, y=505)

# ---------- PRODUCT CARDS ----------
def product_card(px, img_file, title, price):
    card = ctk.CTkFrame(root, width=240, height=120,
                        fg_color=WHITE, corner_radius=12,
                        border_width=1, border_color="black")
    card.place(x=px, y=545)

    try:
        prod_img = Image.open(img_file).resize((80, 80))
        prod_photo = ImageTk.PhotoImage(prod_img)
        ctk.CTkLabel(card, image=prod_photo, text="").place(x=5, y=10)
    except:
        pass

    ctk.CTkLabel(card, text=title,
                 font=("Poppins", 13, "bold")).place(x=95, y=10)

    ctk.CTkLabel(card, text="★★★★★",
                 font=("Arial", 13), text_color="#f4b400").place(x=95, y=40)

    ctk.CTkLabel(card, text=price,
                 font=("Poppins", 13)).place(x=95, y=70)

product_card(50, "images/4.jpg", "Hydrating Cream", "$27.99")
product_card(330, "images/5.jpg", "Facial Serum", "$29.99")

# ---------- EXPLORE BUTTON ----------
explore_btn = ctk.CTkButton(root, text="Explore more",
                            width=150, height=40,
                            fg_color="#C67C80", text_color="black",
                            corner_radius=18,
                            border_color="black", border_width=2,
                            font=("Poppins", 15, "bold"),
                            command=open_home3)

explore_btn.place(x=620, y=580)

root.mainloop()
