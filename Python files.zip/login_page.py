import customtkinter as ctk
from PIL import Image, ImageTk
import os, subprocess, re, hashlib, base64
from db_config import get_connection   

os.chdir(os.path.dirname(os.path.abspath(__file__)))

ctk.set_appearance_mode("light")

root = ctk.CTk()
root.title("Login page")
root.geometry("900x720")
root.configure(fg_color="#E5B8FF")
# ----------- PASSWORD HASH VERIFICATION HELPERS --------

def verify_password(stored_hash, entered_password):
    """
    stored_hash format:
    pbkdf2_sha256$iterations$salt$hash
    """
    try:
        algo, iterations, salt_b64, hash_b64 = stored_hash.split("$")
        iterations = int(iterations)

        salt = base64.b64decode(salt_b64)
        correct_hash = base64.b64decode(hash_b64)

        entered_hash = hashlib.pbkdf2_hmac(
            "sha256",
            entered_password.encode(),
            salt,
            iterations
        )

        return entered_hash == correct_hash
    except:
        return False
# ------------------- DB LOGIN CHECK --------------------

def check_login(email, pwd):

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT password FROM users WHERE email=%s", (email,))
        row = cursor.fetchone()

        cursor.close()
        conn.close()

        if row is None:
            return False, "Email not registered."

        stored_hash = row[0]

        if verify_password(stored_hash, pwd):
            return True, "Login successful"
        else:
            return False, "Incorrect password."

    except Exception as e:
        print("DB ERROR (check_login):", e)
        return False, "Database error occurred."
# --------------------- POPUP ERROR ----------------------

def error_popup(msg):
    error = ctk.CTkToplevel(root)
    error.title("Error")
    error.geometry("320x120")
    ctk.CTkLabel(error, text=msg, font=("Arial", 14)).pack(pady=15)
    ctk.CTkButton(error, text="OK", command=error.destroy).pack()

# --------------------- OPEN SCREENS ---------------------
def open_signup():
    root.destroy()
    subprocess.Popen(["python", "signup_page.py"])

def open_forgot_password():
    root.destroy()
    subprocess.Popen(["python", "Change_password_screen.py"])

def open_home():
    root.destroy()
    subprocess.Popen(["python", "homescreen_1.py"])
# --------------------- LOGIN LOGIC ----------------------

def login_clicked():
    email = email_entry.get().strip()
    pwd = pass_entry.get().strip()

    # --------- Empty Field Validation ---------
    if email == "" or pwd == "":
        error_popup("Please enter Email and Password.")
        return

    # --------- Email Format Validation ---------
    if not re.fullmatch(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}", email):
        error_popup("Please enter a valid email address.")
        return

    # --------- DB Authentication ---------
    ok, msg = check_login(email, pwd)

    if ok:
        open_home()
    else:
        error_popup(msg)

# ----------------------- UI SETUP -----------------------

# IMAGE
try:
    img = Image.open("images/beauty_icon.png").resize((348, 348))
    photo = ImageTk.PhotoImage(img)
    img_label = ctk.CTkLabel(root, image=photo, text="")
    img_label.place(relx=0.5, y=140, anchor="center")
except:
    img_label = ctk.CTkLabel(root, text="(Image Missing)")
    img_label.place(relx=0.5, y=140, anchor="center")

# TEXT
ctk.CTkLabel(
    root, text="Welcome back", 
    font=("Arial Rounded MT Bold", 32, "bold"),
).place(relx=0.5, y=270, anchor="center")

ctk.CTkLabel(
    root, text="Login into your personalized beauty  journey",
    font=("Arial", 18),
).place(relx=0.5, y=310, anchor="center")

# EMAIL
ctk.CTkLabel(root, text="Email address", font=("Arial", 16, "bold")).place(x=250, y=350)
email_entry = ctk.CTkEntry(root, width=400, height=40)
email_entry.place(x=250, y=380)

# PASSWORD
ctk.CTkLabel(root, text="Password", font=("Arial", 16, "bold")).place(x=250, y=430)
pass_entry = ctk.CTkEntry(root, width=400, height=40, show="*")
pass_entry.place(x=250, y=460)

# SHOW / HIDE PASSWORD CHECKBOX
show_password_var = ctk.BooleanVar()

def toggle_password():
    if show_password_var.get():
        pass_entry.configure(show="")
    else:
        pass_entry.configure(show="*")

ctk.CTkCheckBox(
    root,
    text="Show password",
    variable=show_password_var,
    command=toggle_password
).place(x=250, y=510)

# FORGOT PASSWORD
forgot_btn = ctk.CTkButton(
    root, text="Forgot password",
    fg_color="transparent",
    text_color="blue",
    hover_color="white",
    width=120,
    command=open_forgot_password
)
forgot_btn.place(x=480, y=505)

# LOGIN BUTTON
ctk.CTkButton(
    root, text="Login",
    width=300, height=55,
    fg_color="#BE8EEA", font=("inter",20,"bold"),
    hover_color="#A978D3",
    border_color="black", border_width=2,
    corner_radius=40, text_color="black",
    command=login_clicked
).place(relx=0.5, y=570, anchor="center")

# SIGN UP
ctk.CTkLabel(root, text="Don’t have your account?").place(relx=0.4, y=630)

signup_label = ctk.CTkLabel(root, text="Sign Up", text_color="blue", cursor="hand2")
signup_label.place(relx=0.6, y=630)
signup_label.bind("<Button-1>", lambda e: open_signup())

root.mainloop()
