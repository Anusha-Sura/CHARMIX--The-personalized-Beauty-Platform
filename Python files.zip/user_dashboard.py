import customtkinter as ctk
from tkinter import *

# ---------- APP CONFIG ----------
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

root = ctk.CTk()
root.title("Charmix Admin Dashboard")
root.geometry("1100x700")
root.configure(fg_color="#D6A7F5")

# ---------- SIDEBAR ----------
sidebar = ctk.CTkFrame(root, width=220, fg_color="#8B5FC0")
sidebar.pack(side="left", fill="y")

# Charmix logo
title_label = ctk.CTkLabel(sidebar, text="Charmix", font=("Arial", 28, "bold"), text_color="white")
title_label.place(x=20, y=20)

# Sidebar menu
menu_items = ["Products", "Orders", "User", "Add Products", "Settings"]
y_pos = 100

for item in menu_items:
    btn = ctk.CTkButton(
        sidebar,
        text=item,
        fg_color="#D9D9D9" if item == "User" else "#8B5FC0",  # Highlight Users
        text_color="black" if item == "User" else "white",
        hover_color="#A889D9",
        width=200,
        height=40,
        corner_radius=5,
        font=("Inter", 18, "bold")
    )
    btn.place(x=10, y=y_pos)
    y_pos += 60

# ---------- TOP HEADER ----------
header = ctk.CTkFrame(root, height=70, fg_color="#8B5FC0")
header.place(x=220, y=0, relwidth=1)

ctk.CTkLabel(header, text="User", font=("Arial", 28, "bold"), text_color="white").place(relx=0.35, rely=0.25)

# ---------- MAIN SECTION ----------
main_frame = ctk.CTkFrame(root, fg_color="#EAC4FF", corner_radius=25, width=800, height=580)
main_frame.place(x=250, y=100)

content = ctk.CTkFrame(main_frame, fg_color="white", corner_radius=15, width=750, height=520)
content.place(relx=0.5, rely=0.5, anchor="center")

# ---------- TABLE HEADER ----------
headers = ["User Id", "Email Id", "Joined Date"]
x_positions = [80, 300, 550]

for i, text in enumerate(headers):
    ctk.CTkLabel(
        content,
        text=text,
        font=("Arial", 18, "bold"),
        text_color="black"
    ).place(x=x_positions[i], y=30)

# ---------- USER DATA ----------
user_data = [
    ("Abhi", "abhi@gmail.com", "04/04/2025"),
    ("Ram", "ram@gmail.com", "04/29/2025"),
    ("Sai", "sai@gmail.com", "04/27/2025"),
    ("Kiran", "kiran@gmail.com", "06/16/2025"),
]

y = 90
for name, email, date in user_data:
    ctk.CTkLabel(content, text=name, font=("Arial", 16), text_color="black").place(x=80, y=y)
    ctk.CTkLabel(content, text=email, font=("Arial", 16), text_color="black").place(x=300, y=y)
    ctk.CTkLabel(content, text=date, font=("Arial", 16), text_color="black").place(x=550, y=y)
    y += 60

root.mainloop()
