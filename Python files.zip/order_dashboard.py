import customtkinter as ctk
from tkinter import *

# --------- APP CONFIG ---------
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

root = ctk.CTk()
root.title("Charmix Orders")
root.geometry("1100x700")
root.configure(fg_color="#E3D9F5")  # Outer light lavender


# --------- COLORS ---------
SIDE_BG = "#A076CC"
ACTIVE_BG = "#D9D4D4"
WHITE = "#FFFFFF"
TEXT = "#000000"
SUCCESS_BG = "#4AAE9B"
SUCCESS_TEXT = "#FFFFFF"


# --------- LEFT SIDEBAR ---------
sidebar = ctk.CTkFrame(root, width=220, height=700, fg_color=SIDE_BG)
sidebar.place(x=0, y=0)

title = ctk.CTkLabel(sidebar, text="Charmix", text_color="white",
                     font=("Arial", 28, "bold"))
title.place(x=30, y=30)

menu_items = ["Products", "Orders", "Users", "Add Products", "Settings"]

y_pos = 120
for item in menu_items:
    if item == "Orders":
        btn = ctk.CTkButton(sidebar, text=item,
                            fg_color=ACTIVE_BG,
                            text_color="black",
                            font=("Arial", 18, "bold"),
                            corner_radius=0,
                            width=200, height=50)
    else:
        btn = ctk.CTkButton(sidebar, text=item,
                            fg_color=SIDE_BG,
                            hover_color="#875BB5",
                            text_color="white",
                            font=("Arial", 18),
                            corner_radius=0,
                            width=200, height=50)
    btn.place(x=0, y=y_pos)
    y_pos += 60


# --------- TOP HEADER BAR ---------
header_frame = ctk.CTkFrame(root, fg_color=SIDE_BG, width=1100, height=70)
header_frame.place(x=0, y=0)

# LEFT SIDE — Charmix
header_left = ctk.CTkLabel(header_frame, 
                           text="Charmix", 
                           text_color="white",
                           font=("Arial", 26, "bold"))
header_left.place(x=30, y=18)

# CENTER — Orders
header_center = ctk.CTkLabel(header_frame, 
                             text="Orders", 
                             text_color="white",
                             font=("Arial", 28, "bold"))
header_center.place(relx=0.5, rely=0.5, anchor="center")


# --------- MAIN PAGE CONTAINER ---------
main_frame = ctk.CTkFrame(root, fg_color="#EBD9FF", width=800, height=500)
main_frame.place(x=260, y=110)

table_frame = ctk.CTkFrame(main_frame, fg_color=WHITE, width=720, height=420)
table_frame.place(x=40, y=40)


# --------- TABLE HEADERS ---------
headers = ["Order ID", "User", "Items", "Total", "Status"]
x_positions = [40, 190, 330, 430, 540]

for idx, head in enumerate(headers):
    lbl = ctk.CTkLabel(table_frame, text=head, text_color="black",
                       font=("Arial", 20, "bold"))
    lbl.place(x=x_positions[idx], y=15)


# --------- ORDER ROWS ---------
orders = [
    ["292929", "Abhi", 1, "$25", "Success"],
    ["444444", "Ram", 1, "$25", "Success"],
    ["272727", "Sai", 1, "$23", "Success"],
    ["161616", "Kiran", 1, "$30", "Success"],
]

y = 70
for order in orders:
    # Order ID
    ctk.CTkLabel(table_frame, text=order[0], text_color="black",
                 font=("Arial", 18)).place(x=50, y=y)

    # User
    ctk.CTkLabel(table_frame, text=order[1], text_color="black",
                 font=("Arial", 18)).place(x=200, y=y)

    # Items
    ctk.CTkLabel(table_frame, text=str(order[2]), text_color="black",
                 font=("Arial", 18)).place(x=340, y=y)

    # Total
    ctk.CTkLabel(table_frame, text=order[3], text_color="black",
                 font=("Arial", 18)).place(x=440, y=y)

    # Status Badge
    ctk.CTkButton(table_frame, text="Success",
                  fg_color=SUCCESS_BG, hover_color=SUCCESS_BG,
                  text_color=SUCCESS_TEXT,
                  width=100, height=30,
                  font=("Arial", 16, "bold"),
                  corner_radius=20).place(x=525, y=y)

    y += 60


root.mainloop()