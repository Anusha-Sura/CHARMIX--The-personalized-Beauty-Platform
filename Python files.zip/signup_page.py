import customtkinter as ctk
from PIL import Image, ImageTk
import subprocess
from tkinter import messagebox
from db_config import get_connection   # backend connector
import re
import os, hashlib, base64

ctk.set_appearance_mode("light")

root = ctk.CTk()
root.title("Sign up page")
root.geometry("900x750")
root.configure(fg_color="#E5B8FF")

# --------- NAVIGATION FUNCTION ---------
def go_back_to_login():
    root.destroy()
    subprocess.Popen(["python", "login_page.py"])


# --------- PASSWORD HASHING  ---------
def hash_password(password: str) -> str:
    """
    Hash with PBKDF2-HMAC-SHA256 + random salt.
    Stored format: pbkdf2_sha256$iterations$salt$hash
    """
    iterations = 120000
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
    salt_b64 = base64.b64encode(salt).decode()
    hash_b64 = base64.b64encode(dk).decode()
    return f"pbkdf2_sha256${iterations}${salt_b64}${hash_b64}"


# --------- CHECK IF EMAIL EXISTS ---------
def email_exists(email: str) -> bool:
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM users WHERE email=%s LIMIT 1", (email,))
        result = cursor.fetchone()
        cursor.close()
        conn.close()
        return result is not None
    except Exception as e:
        print("DB ERROR (email_exists):", e)
        return False


# --------- INSERT USER TO DATABASE ---------
def insert_user(first, last, email, hashed_pw):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        sql = """
            INSERT INTO users (first_name, last_name, email, password)
            VALUES (%s, %s, %s, %s)
        """
        cursor.execute(sql, (first, last, email, hashed_pw))
        conn.commit()

        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print("DB ERROR (insert_user):", e)
        return False


# --------- VALIDATION FUNCTIONS ----------
def is_valid_name(name):
    return bool(re.fullmatch(r"[A-Za-z]{2,}", name))

def is_valid_email(email):
    return bool(re.fullmatch(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}", email))


# --------- SIGNUP VALIDATION ---------
def signup_action():
    fn = first_name.get().strip()
    ln = last_name.get().strip()
    em = email_entry.get().strip()
    pw = password.get().strip()
    cpw = confirm_password.get().strip()

    # --- Empty field check ---
    if not fn or not ln or not em or not pw or not cpw:
        messagebox.showerror("Missing Data", "Please fill all fields.")
        return

    # --- Name Validation ---
    if not is_valid_name(fn):
        messagebox.showerror("Invalid Name", "First name must contain only letters and be at least 2 characters.")
        return

    if not is_valid_name(ln):
        messagebox.showerror("Invalid Name", "Last name must contain only letters and be at least 2 characters.")
        return

    # --- Email Validation ---
    if not is_valid_email(em):
        messagebox.showerror("Invalid Email", "Please enter a valid email address.")
        return

    # --- Password Match ---
    if pw != cpw:
        messagebox.showerror("Password Error", "Passwords do not match.")
        return

    # --- Email Exists Check (OPTION 2) ---
    if email_exists(em):
        messagebox.showerror("Email Exists", "This email is already registered. Please login.")
        return

    # --- Hash Password (OPTION 3) ---
    hashed_pw = hash_password(pw)

    # --- Insert into DB ---
    if insert_user(fn, ln, em, hashed_pw):
        messagebox.showinfo("Success", "Account created successfully!")
        go_back_to_login()
    else:
        messagebox.showerror("Database Error", "Something went wrong while creating your account.")


# ---------------------- IMAGE ----------------------
try:
    img = Image.open("images/beauty_icon.png").resize((345, 345))
    photo = ImageTk.PhotoImage(img)
    img_label = ctk.CTkLabel(root, image=photo, text="")
    img_label.place(relx=0.5, y=120, anchor="center")
except:
    ctk.CTkLabel(root, text="(Image Missing)").place(relx=0.5, y=120, anchor="center")


# ---------------------- TITLE ----------------------
ctk.CTkLabel(
    root,
    text="Create your charmix account",
    font=("Arial Rounded MT Bold", 28, "bold"),
    text_color="black",
).place(relx=0.5, y=260, anchor="center")


# ---------------------- FORM INPUTS ----------------------
ctk.CTkLabel(root, text="First name", font=("Arial", 15, "bold")).place(x=270, y=300)
first_name = ctk.CTkEntry(root, width=400, height=37)
first_name.place(x=270, y=330)

ctk.CTkLabel(root, text="Last name", font=("Arial", 15, "bold")).place(x=270, y=380)
last_name = ctk.CTkEntry(root, width=400, height=37)
last_name.place(x=270, y=410)

ctk.CTkLabel(root, text="Email Address", font=("Arial", 15, "bold")).place(x=270, y=460)
email_entry = ctk.CTkEntry(root, width=400, height=37)
email_entry.place(x=270, y=490)

ctk.CTkLabel(root, text="Password", font=("Arial", 15, "bold")).place(x=270, y=540)
password = ctk.CTkEntry(root, width=400, height=37, show="*")
password.place(x=270, y=570)

ctk.CTkLabel(root, text="Confirm Password", font=("Arial", 15, "bold")).place(x=270, y=620)
confirm_password = ctk.CTkEntry(root, width=400, height=37, show="*")
confirm_password.place(x=270, y=650)


# ---------------------- SIGN UP BUTTON ----------------------
signup_btn = ctk.CTkButton(
    root,
    text="Sign up",
    width=300,
    height=40,
    fg_color="#BE8EEA",
    hover_color="#A978D3",
    border_color="black",
    border_width=2,
    corner_radius=40,
    font=("Arial Rounded MT Bold", 20),
    text_color="black",
    command=signup_action
)
signup_btn.place(relx=0.5, y=720, anchor="center")

root.mainloop()
