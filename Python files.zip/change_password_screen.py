import customtkinter as ctk
from PIL import Image, ImageTk
import tkinter.messagebox as msg
import subprocess
import os, re, hashlib, base64
from db_config import get_connection  

os.chdir(os.path.dirname(os.path.abspath(__file__)))

ctk.set_appearance_mode("light")

root = ctk.CTk()
root.title("Change Password screen")
root.geometry("900x720")
root.configure(fg_color="#E5B8FF")

# -------- PASSWORD HASHING & VERIFY FUNCTION -------

def hash_password(password):
    salt = os.urandom(16)
    iterations = 200000

    hashed = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode(),
        salt,
        iterations
    )

    return f"pbkdf2_sha256${iterations}${base64.b64encode(salt).decode()}${base64.b64encode(hashed).decode()}"


def verify_password(stored_hash, entered_password):
    try:
        algo, iterations, salt_b64, hash_b64 = stored_hash.split("$")
        iterations = int(iterations)

        salt = base64.b64decode(salt_b64)
        correct_hash = base64.b64decode(hash_b64)

        entered_hash = hashlib.pbkdf2_hmac(
            "sha256",
            entered_password.encode(),
            salt,
            iterations
        )
        return entered_hash == correct_hash
    except:
        return False

# ---------------- UPDATE PASSWORD ------------------

def update_password_in_db(email, new_pass):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT password FROM users WHERE email=%s", (email,))
        row = cursor.fetchone()

        if row is None:
            return False, "Email not found."

        old_hash = row[0]

        # Check if new password is same as old
        if verify_password(old_hash, new_pass):
            return False, "New password cannot be the same as old password."

        # Hash new password
        new_hash = hash_password(new_pass)

        cursor.execute("UPDATE users SET password=%s WHERE email=%s",
                       (new_hash, email))
        conn.commit()

        cursor.close()
        conn.close()
        return True, "Password changed successfully!"

    except Exception as e:
        print("DB ERROR:", e)
        return False, "Database error occurred."

# ------ VALIDATE + CHANGE PASSWORD + REDIRECT -------

def validate_change_password():
    email = email_entry.get().strip()
    new_pass = new_pass_entry.get().strip()
    confirm_pass = confirm_pass_entry.get().strip()

    # Empty fields
    if not email or not new_pass or not confirm_pass:
        msg.showerror("Error", "All fields are required.")
        return

    # Email format
    if not re.fullmatch(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}", email):
        msg.showerror("Error", "Enter a valid email address.")
        return

    # Password match
    if new_pass != confirm_pass:
        msg.showerror("Error", "Passwords do not match!")
        return

    # Password length
    if len(new_pass) < 6:
        msg.showerror("Error", "Password must be at least 6 characters.")
        return

    # Try updating DB
    ok, message = update_password_in_db(email, new_pass)

    if ok:
        msg.showinfo("Success", message)
        root.destroy()
        subprocess.Popen(["python", "login_page.py"])
    else:
        msg.showerror("Error", message)



#-------------- IMAGE TOP-------------
try:
    img = Image.open("images/beauty_icon.png").resize((348, 348))
    photo = ImageTk.PhotoImage(img)
    img_label = ctk.CTkLabel(root, image=photo, text="")
    img_label.place(relx=0.5, y=140, anchor="center")
except:
    img_label = ctk.CTkLabel(root, text="(Image Missing)")
    img_label.place(relx=0.5, y=140, anchor="center")


# -------------LABELS -------------
ctk.CTkLabel(
    root, text="Change  Password",
    font=("Arial Rounded MT Bold", 32, "bold"),
).place(relx=0.5, y=270, anchor="center")

# EMAIL
ctk.CTkLabel(root, text="Email", font=("Arial", 16, "bold")).place(x=250, y=330)
email_entry = ctk.CTkEntry(root, width=400, height=40)
email_entry.place(x=250, y=360)

# NEW PASSWORD
ctk.CTkLabel(root, text="New Password", font=("Arial", 16, "bold")).place(x=250, y=410)
new_pass_entry = ctk.CTkEntry(root, width=400, height=40, show="*")
new_pass_entry.place(x=250, y=440)

# CONFIRM PASSWORD
ctk.CTkLabel(root, text="Confirm Password", font=("Arial", 16, "bold")).place(x=250, y=490)
confirm_pass_entry = ctk.CTkEntry(root, width=400, height=40, show="*")
confirm_pass_entry.place(x=250, y=520)

# CONFIRM BUTTON
ctk.CTkButton(
    root, text="Confirm Password",
    width=200, height=55,
    fg_color="#BE8EEA", font=("inter", 18, "bold"),
    hover_color="#A978D3", border_color="black", border_width=2,
    corner_radius=40, text_color="black",
    command=validate_change_password
).place(x=250, y=600)

# BACK BUTTON
ctk.CTkButton(
    root, text="Back",
    width=130, height=55,
    fg_color="#BE8EEA", font=("inter", 18, "bold"),
    hover_color="#A978D3", border_color="black", border_width=2,
    corner_radius=40, text_color="black",
    command=lambda: [root.destroy(), subprocess.Popen(["python", "login_page.py"])]
).place(x=500, y=600)

root.mainloop()
