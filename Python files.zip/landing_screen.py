import customtkinter as ctk
from PIL import Image, ImageTk
import subprocess
import sys

# ----------------- APP CONFIG -----------------
ctk.set_appearance_mode("light")

root = ctk.CTk()
root.title("Landing Screen")
root.geometry("900x720")
root.configure(fg_color="#E5B8FF")   # Background lavender


# ----------------- FUNCTION: OPEN LOGIN PAGE -----------------
def open_login():
    root.destroy()  # close landing page

    # Open login page 
    subprocess.Popen([sys.executable, "login_page.py"])


# ----------------- TOP IMAGE -----------------
try:
    img = Image.open("images/beauty_icon.png").resize((348, 348))
    photo = ImageTk.PhotoImage(img)
    img_label = ctk.CTkLabel(root, image=photo, text="")
    img_label.place(relx=0.5, y=150, anchor="center")
except:
    img_label = ctk.CTkLabel(root, text="(Image Missing)", text_color="black")
    img_label.place(relx=0.5, y=150, anchor="center")


# ----------------- TEXT SECTION -----------------
title_label = ctk.CTkLabel(
    root,
    text="Your personalized beauty\njourney begins here",
    font=("Arial Rounded MT Bold", 32, "bold"),
    text_color="black"
)
title_label.place(relx=0.5, y=310, anchor="center")

subtitle_label = ctk.CTkLabel(
    root,
    text="Discover your glow",
    font=("Arial", 20),
    text_color="black"
)
subtitle_label.place(relx=0.5, y=360, anchor="center")


# ----------------- GET STARTED BUTTON -----------------
get_started_btn = ctk.CTkButton(
    root,
    text="Get started",
    width=240,
    height=60,
    fg_color="#F7D9FF",       
    hover_color="#EEC5FA",
    text_color="black",
    font=("Arial", 22, "bold"),
    corner_radius=40,
    border_width=3,
    border_color="black",
    command=open_login     # NAVIGATION  HERE
)
get_started_btn.place(relx=0.5, y=430, anchor="center")


# ----------------- CARD FUNCTION -----------------
def make_card(x_pos, text):
    card = ctk.CTkFrame(
        root,
        width=210,
        height=130,
        corner_radius=25,
        fg_color="#D1A8FF",        
        border_color="white",
        border_width=3
    )
    card.place(x=x_pos, y=530)

    icon_label = ctk.CTkLabel(card, text="✨", font=("Arial", 32))  # smaller icon
    icon_label.place(relx=0.5, y=40, anchor="center")

    text_label = ctk.CTkLabel(card, text=text, font=("Arial", 16))
    text_label.place(relx=0.5, y=95, anchor="center")


# ----------------- 3 CARDS WITH CORRECT SPACING -----------------
make_card(115, "Custom routines")
make_card(345, "Curated products")
make_card(575, "Trending products")

root.mainloop()
