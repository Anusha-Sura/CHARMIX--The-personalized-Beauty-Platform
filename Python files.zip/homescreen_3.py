import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
import customtkinter as ctk
from PIL import Image, ImageTk

# DB cart system
from cart_system import add_to_cart_db

# ---------- APP CONFIG ----------
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

root = ctk.CTk()
root.title("Charmix - Products")
root.geometry("1100x750")
root.configure(fg_color="#D6A7F5")

# ---------- COLORS ----------
WHITE = "#FFFFFF"
LAVENDER = "#D6A7F5"
TEXT = "#222222"

# ---------- IMAGE LOADER ----------
def load_icon(path, size):
    try:
        img = Image.open(path).convert("RGBA").resize((size, size), Image.LANCZOS)
        return ImageTk.PhotoImage(img)
    except:
        return None

# LOAD ICONS
search_img = load_icon("images/2.jpg", 28)
shine_icon = load_icon("images/shine.png", 45)
cart_icon  = load_icon("images/cart.png", 45)


# ---------- HEADER ----------
menu_btn = ctk.CTkButton(
    root, text="☰", width=50, height=50,
    fg_color=LAVENDER, hover_color="#B88CD9",
    font=("Arial", 30), corner_radius=50
)
menu_btn.place(x=20, y=15)

search_frame = ctk.CTkFrame(
    root, width=650, height=45,
    border_color="#D9D9D9", border_width=3,
    fg_color=WHITE, corner_radius=40
)
search_frame.place(x=200, y=20)

# Search Icon
if search_img:
    ctk.CTkLabel(search_frame, image=search_img, text="").place(x=10, y=10)
else:
    ctk.CTkLabel(search_frame, text="🔍", font=("Arial", 24)).place(x=10, y=12)

search_entry = ctk.CTkEntry(
    search_frame,
    placeholder_text="Search",
    width=580, height=40,
    border_width=0, fg_color=WHITE
)
search_entry.place(x=50, y=8)

# ---------- SHINE ICON ----------
ctk.CTkButton(
    root,
    width=48, height=48,
    corner_radius=50,
    fg_color="#D6A7F5",
    hover_color="#EEDBFF",
    image=shine_icon,
    text=""
).place(x=900, y=18)

# Cart icon
cart_label = ctk.CTkLabel(root, image=cart_icon, text="")
cart_label.place(x=970, y=25)

def go_to_checkout():
    root.destroy()
    import check_out_screen

cart_label.bind("<Button-1>", lambda e: go_to_checkout())

# Badge
cart_count = 0
cart_badge = ctk.CTkLabel(
    root, text="0",
    width=22, height=22,
    fg_color="#E0568F",
    text_color="white",
    corner_radius=11,
    font=("Arial", 12, "bold")
)
cart_badge.place_forget()

def update_cart_badge():
    global cart_count
    cart_count += 1
    cart_badge.configure(text=str(cart_count))
    cart_badge.place(x=995, y=10)


# ---------- POPUP ----------
def show_added_popup():
    popup = ctk.CTkToplevel(root)
    popup.geometry("250x120+450+200")
    popup.configure(fg_color="white")
    popup.title("")

    ctk.CTkLabel(
        popup, text="✓ Added to Cart",
        font=("Arial", 18, "bold"),
        text_color="green"
    ).pack(pady=20)

    root.after(600, popup.destroy)


# ---------- PRODUCT CARD ----------
def make_product(parent, x, y, img_file, title, price):
    frame = ctk.CTkFrame(
        parent, fg_color=WHITE,
        width=230, height=180,
        corner_radius=20,
        border_color="#D9D9D9", border_width=2
    )
    frame.place(x=x, y=y)

    # Product image
    try:
        img = Image.open(img_file).resize((100, 100))
        photo = ImageTk.PhotoImage(img)
        ctk.CTkLabel(frame, image=photo, text="").place(x=65, y=5)
        frame.image = photo
    except:
        ctk.CTkLabel(frame, text="(no image)", font=("Arial", 12)).place(x=70, y=20)

    # Title
    ctk.CTkLabel(
        frame, text=title,
        font=("Arial", 13, "bold"),
        text_color=TEXT, wraplength=190, justify="left"
    ).place(x=10, y=110)

    # Price
    ctk.CTkLabel(
        frame, text=price,
        font=("Arial", 15, "bold"),
        text_color=TEXT
    ).place(x=10, y=140)

    # Add to Cart button (UPDATED TO USE DB + CLEAN PRICE)
    ctk.CTkButton(
        frame,
        text="Add to cart",
        fg_color="#D6A7F5",
        width=90,
        text_color="black",
        font=("Arial", 12, "bold"),
        border_color="black",
        border_width=2,
        height=28,
        corner_radius=15,
        command=lambda: (
            add_to_cart_db(
                1, img_file, title, float(price.replace("$", ""))
            ),
            update_cart_badge(),
            show_added_popup()
        )
    ).place(x=120, y=140)


# ---------- BACK BUTTON ----------
def go_back():
    root.destroy()
    import homescreen_1

back_btn = ctk.CTkButton(
    root, text="⟵ Back",
    width=80, height=35,
    fg_color="#CFA0E9",
    hover_color="#B07AD9",
    text_color="black",
    font=("Arial", 14, "bold"),
    corner_radius=15,
    command=go_back
)
back_btn.place(x=25, y=65)


# ---------- MAIN CANVAS ----------
canvas = ctk.CTkFrame(
    root, fg_color=LAVENDER,
    width=1040, height=700,
    corner_radius=20
)
canvas.place(x=30, y=100)


# ---------- ROW 1 ----------
row1 = ctk.CTkFrame(canvas, fg_color=WHITE, width=1000, height=200, corner_radius=30)
row1.place(x=10, y=8)

make_product(row1, 10, 15, "images/S13.jpg", "Proactiv Green Tea and Hyaluronic Acid Moisturizer", "$30")
make_product(row1, 260, 15, "images/S14.jpg", "L’Oreal Paris Collagen Daily Face Moisturizer", "$20")
make_product(row1, 510, 15, "images/S15.jpg", "medicube Triple Collagen Cream", "$35")
make_product(row1, 760, 15, "images/S16.jpg", "True Botanicals Chebula Extreme Cream", "$25")

ctk.CTkFrame(canvas, height=5, width=950, fg_color="#C488FF").place(x=40, y=215)


# ---------- ROW 2 ----------
row2 = ctk.CTkFrame(canvas, fg_color=WHITE, width=1000, height=200, corner_radius=30)
row2.place(x=10, y=220)

make_product(row2, 10, 15, "images/S17.jpg", "KORA Organics Turmeric Glow Foaming Cleanser", "$30")
make_product(row2, 260, 15, "images/S18.jpg", "RéVive Foaming Facial Cleanser", "$25")
make_product(row2, 510, 15, "images/S19.jpg", "KORA Organics Active Algae Calming Cleansing Balm", "$25")
make_product(row2, 760, 15, "images/S20.jpg", "La Roche-Posay Toleriane Hydrating Gentle Cleanser", "$20")

ctk.CTkFrame(canvas, height=5, width=950, fg_color="#C488FF").place(x=40, y=445)


# ---------- ROW 3 ----------
row3 = ctk.CTkFrame(canvas, fg_color=WHITE, width=1000, height=200, corner_radius=30)
row3.place(x=10, y=430)

make_product(row3, 10, 15, "images/S21.jpg", "Beauty of Joseon Glow Deep Serum", "$15")
make_product(row3, 260, 15, "images/S22.jpg", "Collagen & Retinol Serum For Face", "$20")
make_product(row3, 510, 15, "images/S23.jpg", "Pure Hyaluronic Acid Face Serum", "$30")
make_product(row3, 760, 15, "images/S24.jpg", "SheaMoisture Hyaluronic Acid Serum", "$10")

root.mainloop()
