import customtkinter as ctk

# ---------- APP CONFIG ----------
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

root = ctk.CTk()
root.title("Charmix Admin Dashboard")
root.geometry("1100x700")
root.configure(fg_color="#D6A7F5")

# ---------- COLORS ----------
PURPLE_TOP = "#9B6EDC"
PURPLE_SIDE = "#9260D1"
WHITE = "#FFFFFF"

# ---------- TOP HEADER ----------
header_frame = ctk.CTkFrame(root, height=70, width=1100, fg_color=PURPLE_TOP, corner_radius=0)
header_frame.place(x=0, y=0)

# UPDATED — matches reference
title_label = ctk.CTkLabel(
    header_frame,
    text="Charmix",
    font=("Inter", 28, "bold"),
    text_color="white"
)
title_label.place(x=30, y=18)

center_title = ctk.CTkLabel(
    header_frame,
    text="Products",
    text_color="white",
    font=("Inter", 24, "bold")
)
center_title.place(relx=0.5, y=20, anchor="center")

user_label = ctk.CTkLabel(
    header_frame,
    text="Anusha Sura",
    text_color="white",
    font=("Inter", 20, "bold")
)
user_label.place(x=920, y=20)

# ---------- LEFT MENU ----------
side_menu = ctk.CTkFrame(root, width=220, height=700, fg_color=PURPLE_SIDE, corner_radius=0)
side_menu.place(x=0, y=70)

def menu_button(text, y, active=False):
    return ctk.CTkButton(
        side_menu,
        text=text,
        width=220,
        height=45,
        fg_color=("#D9D4E8" if active else PURPLE_SIDE),
        hover_color="#B89BD9",
        text_color="white" if not active else "#444",
        corner_radius=0,
        font=("Inter", 18, "bold")
    ).place(x=0, y=y)

menu_button("Products", 20, active=True)
menu_button("Orders", 80)
menu_button("Users", 140)
menu_button("Add Products", 200)
menu_button("Settings", 260)

# ---------- MAIN CONTENT ----------
main_frame = ctk.CTkFrame(
    root,
    width=840,
    height=600,
    fg_color="#E6C4FA",
    corner_radius=30
)
main_frame.place(x=240, y=100)


# ---------- METRIC CARD ----------
def metric_card(parent, x, y, number, text):
    card = ctk.CTkFrame(
        parent,
        width=260,
        height=110,
        fg_color=WHITE,
        corner_radius=15
    )
    card.place(x=x, y=y)

    ctk.CTkLabel(card, text=str(number), font=("Inter", 26, "bold"), text_color="#000").place(x=20, y=15)
    ctk.CTkLabel(card, text=text, font=("Inter", 16), text_color="#444").place(x=20, y=60)


# ---------- ROW 1 ----------
metric_card(main_frame, 80, 60, "52", "Total products")
metric_card(main_frame, 450, 60, "4", "Total orders")

# ---------- ROW 2 ----------
metric_card(main_frame, 80, 210, "109$", "Revenue Today")
metric_card(main_frame, 450, 210, "9", "Pending Orders")

# ---------- ROW 3 ----------
metric_card(main_frame, 80, 360, "20", "Out of stock items")


root.mainloop()
