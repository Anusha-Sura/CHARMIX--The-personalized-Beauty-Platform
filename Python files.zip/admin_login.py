import customtkinter as ctk
from PIL import Image, ImageTk

# ---------- APP CONFIG ----------
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

root = ctk.CTk()
root.title("Charmix Admin")
root.geometry("1100x750")
root.configure(fg_color="#D6A7F5")

# ---------- COLORS ----------
WHITE = "#FFFFFF"
PURPLE = "#CFA0E9"
TEXT = "#222222"

# ---------- MAIN FRAME ----------
main_frame = ctk.CTkFrame(root, fg_color="#D6A7F5", width=1100, height=750)
main_frame.place(relx=0.5, rely=0.5, anchor="center")


# ---------- LEFT IMAGE ----------
try:
    img = Image.open("Admin logo.png").resize((500, 600))
    admin_img = ImageTk.PhotoImage(img)
    ctk.CTkLabel(main_frame, image=admin_img, text="").place(x=120, y=140)
except:
    ctk.CTkLabel(main_frame, text="[admin image missing]",
                 font=("Arial", 20)).place(x=170, y=300)


# ---------- RIGHT LOGIN BOX ----------
login_box = ctk.CTkFrame(
    main_frame,
    width=420,
    height=500,
    fg_color=WHITE,
    corner_radius=35
)
login_box.place(x=600, y=130)

# ---------- TITLE ----------
ctk.CTkLabel(login_box,
             text="Charmix Admin",
             font=("Arial", 28, "bold"),
             text_color=TEXT).place(x=90, y=40)

ctk.CTkLabel(login_box,
             text="Sign in to your dashboard",
             font=("Arial", 14),
             text_color="#555555").place(x=120, y=80)

# ---------- USERNAME ----------
ctk.CTkLabel(login_box,
             text="Username",
             font=("Arial", 14, "bold"),
             text_color=TEXT).place(x=50, y=130)

ctk.CTkEntry(login_box,
             width=300,
             height=40,
             fg_color="#E5E5E5",
             border_color="black",
             border_width=2,
             corner_radius=10).place(x=50, y=160)

# ---------- PASSWORD ----------
ctk.CTkLabel(login_box,
             text="Password",
             font=("Arial", 14, "bold"),
             text_color=TEXT).place(x=50, y=220)

ctk.CTkEntry(login_box,
             width=300,
             height=40,
             show="*",
             fg_color="#E5E5E5",
             border_color="black",
             border_width=2,
             corner_radius=10).place(x=50, y=250)

# ---------- LOGIN BUTTON ----------
ctk.CTkButton(
    login_box,
    text="Login",
    width=300,
    height=45,
    fg_color=PURPLE,
    text_color=TEXT,
    hover_color="#EFD9FF",
    corner_radius=20,
    border_color="black",
    border_width=2,
    font=("Arial", 15, "bold")
).place(x=50, y=320)


# ---------- BACK TO USER LOGIN ----------
ctk.CTkButton(
    login_box,
    text="Back to user login",
    width=200,
    height=10,
    fg_color="transparent",
    text_color="black",
    hover_color="#EFE6FF",
    font=("Arial", 14, "bold")
).place(x=110, y=390)


root.mainloop()
